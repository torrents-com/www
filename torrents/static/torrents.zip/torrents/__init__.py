# -*- coding: utf-8 -*-
from collections import namedtuple

Category = namedtuple('Category', ['cat_id','url','title','tag','content','content_main','show_in_home'])
