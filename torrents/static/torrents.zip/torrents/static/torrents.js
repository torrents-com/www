$(function(){
    window.suggestmeyes_loaded = true;

    if ($("div >.filepaths li").length>1){
        $("div >.filepaths >li").addClass("open");
        $("div >.filepaths").treeview({"collapsed":true});
    }

    var featured_images = $("#featured img");
    max_width = featured_images.parent().parent().width();
    $("#featured img").load(function(){
        this_width = $(this).width();
        if (this_width>max_width)
            $(this).css("margin-left", (max_width-this_width)/2+"px"    );
    });

    $("#more").change(function() {
        $(this).toggleClass("checked", $(this).is(":checked"));
    });

    $('html').click(function() {
        $("#more").removeClass("checked").attr("checked",false);
        $(".more ul").css("display","");
    });

    $('.more').click(function(event){
        event.stopPropagation();
    });

    $("a[data-track]").each(function(){
        var elm=$(this), link_href=this.href, target=this.target;
        var data=elm.data("track").split(","), wait=elm.attr("_target");
        elm.click(function(event){
            _gaq.push(['_trackEvent', data[0], data[1], data[2]]);
            if(!target){
                setTimeout(function(){
                    if(!event.stop_redirection) window.location = link_href;
                    }, 100);
                event.preventDefault();
                }
            });
        });

    $("#q").focus();

    $("#view-trailer").each(function(){
        link = $(this).data("link");
        if (link=="") {
            $(this).click(function(e) {
                e.preventDefault();
                var me = $(this);
                var rsearch = me.data("search");
                if (rsearch!="") {
                    $.ajax({
                      dataType: "jsonp",
                      url: "http://gdata.youtube.com/feeds/videos?alt=json&q="+rsearch,
                      cache: false,
                      success: function (data) {
                        entries = data.feed.entry;
                        if (entries && entries.length>0)
                        {
                            id = entries[0].id.$t;
                            id = id.substr(id.lastIndexOf('/') + 1);
                            me.colorbox({iframe:true, innerWidth:560, innerHeight:360, transition:'none', href:"http://www.youtube.com/embed/"+id+"?autoplay=1", open:true});
                        } else {
                            me.html("<span class='icon-error'></span> No trailer available");
                            me.data("search","");
                            me.addClass("disable");
                        }
                      }
                    });
                }
            });
        } else {
            $(this).colorbox({iframe:true, innerWidth:560, innerHeight:360, transition:'none'});
        }
    });

});
